{-# INLINE error #-}
error :: String -> a
error s = _error s
