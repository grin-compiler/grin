keys :: [String]
keys = ["case","class","data","default","deriving","else","hiding", "if","import","in","infix","infixl","instance","interface","let","module","of","renaming","then","to","type","where"]
